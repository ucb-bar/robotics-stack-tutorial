#include <stddef.h>
#include <stdint.h>
#include "pext.h"
// idea: MAX8 on 8 columns of two rows at once, scalar fallback
void kernel_maxpool2d_s8(const int8_t *input, int8_t *output, int N, int C, int IH, int IW, int KH, int KW, int SH, int SW, int PH, int PW, int DH, int DW)
{
    int OH = (IH + 2*PH - DH*(KH-1) - 1) / SH + 1;
    int OW = (IW + 2*PW - DW*(KW-1) - 1) / SW + 1;
    
    // Fast path for common 2x2 stride 2 no-padding case with aligned input
    if (KH == 2 && KW == 2 && SH == 2 && SW == 2 && PH == 0 && PW == 0 && DH == 1 && DW == 1 &&
        IW % 8 == 0 && MB_PEXT_ALIGNED8(input)) {
        
        int input_stride = C * IH * IW;
        int output_stride = C * OH * OW;
        int channel_stride = IH * IW;
        int row_stride = IW;
        
        for (int n = 0; n < N; ++n) {
            const int8_t *input_n = input + n * input_stride;
            int8_t *output_n = output + n * output_stride;
            
            for (int c = 0; c < C; ++c) {
                const int8_t *input_c = input_n + c * channel_stride;
                int8_t *output_c = output_n + c * OH * OW;
                
                for (int oh = 0; oh < OH; ++oh) {
                    int8_t *output_row = output_c + oh * OW;
                    const int8_t *input_row0 = input_c + (oh * 2) * row_stride;
                    const int8_t *input_row1 = input_row0 + row_stride;
                    
                    // Process 8 columns at a time
                    for (int ow = 0; ow < OW; ow += 4) {
                        // Load 8 bytes from each row
                        int64_t row0_chunk = MB_PEXT_LD8(input_row0 + ow * 2);
                        int64_t row1_chunk = MB_PEXT_LD8(input_row1 + ow * 2);
                        
                        // Vertical max
                        int64_t vert_max = mb_pext_max8(row0_chunk, row1_chunk);
                        
                        // Horizontal max of pairs: compare bytes 0-1, 2-3, 4-5, 6-7
                        // Shift by 8 bytes to align pairs
                        int64_t shifted = (int64_t)((uint64_t)vert_max >> 8);
                        int64_t horiz_max = mb_pext_max8(vert_max, shifted);
                        
                        // Extract results from bytes 0, 2, 4, 6
                        output_row[ow] = (int8_t)horiz_max;
                        output_row[ow + 1] = (int8_t)(horiz_max >> 16);
                        output_row[ow + 2] = (int8_t)(horiz_max >> 32);
                        output_row[ow + 3] = (int8_t)(horiz_max >> 48);
                    }
                }
            }
        }
        return;
    }
    
    // General scalar fallback
    int total_elements = N * C * OH * OW;
    for (int idx = 0; idx < total_elements; ++idx) {
        int n = idx / (C * OH * OW);
        int c = (idx / (OH * OW)) % C;
        int oh = (idx / OW) % OH;
        int ow = idx % OW;
        int8_t max_val = INT8_MIN;
        for (int kh = 0; kh < KH; ++kh) {
            int ih = oh * SH - PH + kh * DH;
            if (ih < 0 || ih >= IH) continue;
            for (int kw = 0; kw < KW; ++kw) {
                int iw = ow * SW - PW + kw * DW;
                if (iw < 0 || iw >= IW) continue;
                int8_t val = input[((n * C + c) * IH + ih) * IW + iw];
                if (val > max_val) max_val = val;
            }
        }
        output[idx] = max_val;
    }
}